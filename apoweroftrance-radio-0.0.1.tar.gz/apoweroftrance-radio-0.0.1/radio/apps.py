from django.apps import AppConfig


class RadioConfig(AppConfig):
    name = 'radio'
